var entrada=prompt("Escolha uma opção:\n 1- Pedra,\n2-Papel,\n3-Tesoura")
var transforma= Math.random();
alert("Escolha máquina"+ transforma)
if(transforma<=0.33)
{
    transforma=1;//Pedra

}
else if(transforma>0.33 && transforma<=0.66){
    transforma =2;//Papel
}
else if(transforma>0.66 && transforma<=0.99){
    transforma =2;//tesoura
}
if(entrada==transforma)
{
    alert("Empate");
}
// Pedra>>Tesoura ou Tesoura>>Pedra
if(entrada==1 && transforma==3)
{
    alert("Pedra quebra Tesoura \nGanhador é o usúario");
}
else if(entrada==3 && transforma==1)
{
    alert("Pedra quebra Tesoura\n Ganhador é a máquina");
}
//Tesoura>>Papel
else if(entrada==3 && transforma==2)
{
    alert("Tesoura corta papel \n Ganhador é o usuário");
}
else if(entrada==2 && transforma==3)
{
    alert("Tesoura corta papel \nGanhador é a máquina");
}
//Papel>>Pedra
else if(entrada==2 && transforma==1)
{
    alert("Papel cobre pedra\n Ganhador é o usúario");
}
else if(entrada==1 && transforma==2)
{
    alert("Papel cobre pedra\nGanhador é a máquina");
}




